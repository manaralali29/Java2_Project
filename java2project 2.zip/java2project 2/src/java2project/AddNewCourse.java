package java2project;


	
	import java.awt.Color;
	import java.awt.Font;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.PrintWriter;
	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JTextField;
	import javax.swing.SwingConstants;


	public class AddNewCourse extends JFrame implements ActionListener{

	    JLabel info;
	    JTextField f1, f2, f3 , f4;

	    public AddNewCourse(){
	        
	        super("Add New Course");
	        setSize(400,500);
	        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	        setLocationRelativeTo(null);
	        setLayout(null);
	    
	        
	        JLabel lbl= new JLabel("Add New Course");
	        Font Title_Font = new Font("Cambria", Font.BOLD, 28);
	        lbl.setFont(Title_Font);
	        lbl.setBounds(70,20,220,50);
	        add(lbl);
	   
	        Font Label_Font = new Font("Cambria", Font.BOLD, 14);
	    
	        info= new JLabel("");
	        info.setForeground(Color.RED);
	        info.setFont(Label_Font);
	        info.setBounds(50,80,320,50);
	        add(info);

	        JLabel l1= new JLabel("Course Code*",SwingConstants.RIGHT);
	        l1.setFont(Label_Font);
	        l1.setBounds(30,120,120,50);
	        f1 = new JTextField(10);
	        f1.setBounds(160,130,150,30);

	        JLabel l2= new JLabel("Course Name*",SwingConstants.RIGHT);
	        l2.setFont(Label_Font);    
	        l2.setBounds(30,160,120,50);
	        f2 = new JTextField(10);
	        f2.setBounds(160,170,150,30);

	        JLabel l3= new JLabel("Credit Hours*",SwingConstants.RIGHT);
	        l3.setFont(Label_Font);    
	        l3.setBounds(30,200,120,50);
	        f3 = new JTextField(10);
	        f3.setBounds(160,210,150,30);
	        
	        JLabel l4= new JLabel("Contact Hours*",SwingConstants.RIGHT);
	        l4.setFont(Label_Font);   
	        l4.setBounds(30,240,120,50);
	        f4 = new JTextField(10);
	        f4.setBounds(160,250,150,30);

	     
	        
	        add(l1);
	        add(f1);
	        add(l2);
	        add(f2);
	        add(l3);
	        add(f3);
	        add(l4);
	        add(f4);
	   
	        
	        JButton add_btn = new JButton("Add");
	        add_btn.setBounds(230,290,80,30);
	        add_btn.addActionListener(this);
	        add(add_btn);
	    }

	    public void actionPerformed(ActionEvent e){
	        
	        // read all data from gui
	        String code = f1.getText().trim();
	        String name = f2.getText().trim();
	        String creditHour = f3.getText().trim();
	        String contactHour = f4.getText().trim();
	        
	        PrintWriter outStream = null;
	        try
	        {
	            outStream = new PrintWriter(new FileOutputStream("Course.txt",true));
	            outStream.println(code+","+name+","+creditHour+","+contactHour);
	            outStream.close();
	            info.setText("Course added successfully..");
	        }
	        catch(FileNotFoundException ex)
	        {
	            System.out.println("Error opening the file Course.txt "+ ex.getMessage());
	            info.setText("File Course does not exist..");
	        }
	        

	    }
	

}
