package java2project;


	
	import java.awt.Color;
	import java.awt.Font;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.util.Scanner;
	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JScrollPane;
	import javax.swing.JTextArea;
	import javax.swing.JTextField;
	import javax.swing.SwingConstants;

	public class DisplayStudents extends JFrame implements ActionListener{
	    
	    JTextField f1;
	    JTextArea area;
	    public DisplayStudents(){ 
	        super("Display Students");
	        setSize(400,400);
	        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	        setLocationRelativeTo(null);        
	        setLayout(null);

	        //title
	        JLabel lbl= new JLabel("Display Students");
	        Font Title_Font = new Font("Cambria", Font.BOLD, 28);
	        lbl.setFont(Title_Font);
	        lbl.setBounds(70,20,220,50);
	        add(lbl);
	        
	        Font Label_Font = new Font("Cambria", Font.BOLD, 14);

	        //enter major name
	        JLabel l1= new JLabel("Course Code:",SwingConstants.RIGHT);
	        l1.setFont(Label_Font);
	        l1.setBounds(30,70,120,50);
	        f1 = new JTextField(10);
	        f1.setBounds(160,80,150,30);
	        f1.addActionListener(this);
	        add(l1);
	        add(f1);
	        
	        area = new JTextArea(15,30);
	        JScrollPane scrolledText = new JScrollPane(area);
	        scrolledText.setBounds(50,140,300,150);
	        scrolledText.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	        scrolledText.setHorizontalScrollBarPolicy( JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	        add(scrolledText);
	        
	        
	        JButton back_btn = new JButton("Back");
	        back_btn.setBounds(160,300,80,30);

	        add(back_btn);
	    }
	    
	    public void actionPerformed(ActionEvent e){
	        String code = f1.getText();
	        String names = "";
	        

	         Scanner inputStream = null;
	        // read StudentCourse file
	        try{
	            inputStream = new Scanner(new FileInputStream("StudentCourse.txt"));
	            while(inputStream.hasNextLine()){
	                String line = inputStream.nextLine();
	                String[] tokens = line.split(","); 
	                if (tokens[2].equals(code)){
	                    names += "\t"+tokens[1]+"\n"; 
	                }// end if
	   
	            }//end while 
	            
	            area.setText(names);
	            
	        }
	        catch (FileNotFoundException ex){
	            System.out.println("File studentCourse.txt was not found");
	        }
	        
	        
	      
	    
	    
	    }
	    
	}
	
	


