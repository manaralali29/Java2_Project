package java2project;

	import java.awt.Font;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.util.Scanner;
	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JScrollPane;
	import javax.swing.JTextArea;
	import javax.swing.JTextField;
	import javax.swing.SwingConstants;


	public class DisplayCourses extends JFrame{
	    
	    JTextArea area ;
	    public DisplayCourses(){
	        super("Display Courses");
	        setSize(400,400);
	        setLocationRelativeTo(null);
	        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	        
	        setLayout(null);

	        //title
	        JLabel lbl= new JLabel("Display All Courses");
	        Font Title_Font = new Font("Cambria", Font.BOLD, 24);
	        lbl.setFont(Title_Font);
	        lbl.setBounds(80,20,220,50);
	        add(lbl);
	        
	        Font Label_Font = new Font("Cambria", Font.BOLD, 14);
	   
	        area = new JTextArea(15,150);
	        JScrollPane scrolledText = new JScrollPane(area);
	        scrolledText.setBounds(70,80,250,200);
	        scrolledText.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	        scrolledText.setHorizontalScrollBarPolicy( JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	        add(scrolledText);
	        
	        
	        JButton back_btn = new JButton("Back");
	        back_btn.setBounds(150,300,80,30);

	        add(back_btn);
	        
	        // read all course from Course File
	        Scanner inputStream = null;
	        // read admin from a file
	        try{
	            inputStream = new Scanner(new FileInputStream("Course.txt"));
	            
	            String course_data="";
	            //read all file
	            while(inputStream.hasNextLine()){
	                String line = inputStream.nextLine();
	                String[] tokens = line.split(","); 
	                course_data += tokens[0]+"\t"+tokens[1]+"\n";
	            } // end while loop 
	            
	            area.setText(course_data);
	      
	        }
	        catch (FileNotFoundException ex){
	            System.out.println("File Course.txt was not found");
	        }
	        

	   }

}
