package java2project;

public class java2project {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		adminLoginWindow admin_Login_Window= new adminLoginWindow();
		mainWindow main_Window=new mainWindow();
		
//		admin_Login_Window.setVisible(true);
		main_Window.setVisible(true);

	}

}
