package java2project;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class adminLoginWindow extends JFrame implements ActionListener {

    private JTextField userNameText;
    private JPasswordField passText;
    private JLabel mssg;
    
	//constr
	
	public adminLoginWindow () {
		 
		//window 1
		
		this.setTitle("Admin Login Window");
		this.setSize(400,200);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(new BorderLayout());
		
		  // labels
        JLabel login = new JLabel("Login Page");
        JLabel userNamelbl = new JLabel("User Name :");
        JLabel passlbl = new JLabel("Paswword :");
         mssg = new JLabel("Message:");
		
         
         // initializing the textfields
         userNameText = new JTextField();
         passText = new JPasswordField();
		
         // buttons
         JButton submit = new JButton("Submit");
         submit.addActionListener(this);
         JButton clear = new JButton("Clear");
         clear.addActionListener(this);
         

         //font 
         login.setFont (new Font ("TimesRoman", Font.BOLD | Font.ITALIC, 17));
         
         
         JPanel northPanel = new JPanel(new FlowLayout());
         northPanel.add(login);
         

         JPanel centerPanel = new JPanel(new GridLayout(3,1));
         centerPanel.add(userNamelbl);
         centerPanel.add(userNameText);
         centerPanel.add(passlbl);
         centerPanel.add(passText);
         centerPanel.add(submit);
         centerPanel.add(clear);

         //JPanel southPanel = new JPanel(new GridLayout(1,1));



         //adding to the frame
         add(northPanel,BorderLayout.NORTH);
         add(centerPanel,BorderLayout.CENTER);
         add(mssg,BorderLayout.SOUTH) ;
         //add(southPanel,BorderLayout.SOUTH);

        
		
		
	}
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		 String command = e.getActionCommand();

	        char [] pass = passText.getPassword();
	        char [] myPass = {'4','2','1'};

	        if (command.equals("Submit")) {
	           // System.out.println("submit");
	            if (userNameText.getText().equals("manar") && Arrays.equals(pass,myPass)) {
	                //System.out.println(userNameText.equals("manar") && Arrays.equals(pass,myPass));
	                mssg.setText("Message : You are logged in Successfully");
	              
	                mainWindow main_Window= new mainWindow();
	                main_Window.setVisible(true);   
	            }
	            else {
	                //System.out.println("Sorry!! Check your username and password");
	                mssg.setText("Message : Sorry!! Check your username and password");
	            }

	        }

	        else if (command.equals("Clear")) {
	            userNameText.setText(null);
	            passText.setText(null);
	            mssg.setText(null);
	        }
		
	}

}
