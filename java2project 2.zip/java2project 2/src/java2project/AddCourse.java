package java2project;


	
	
	import java.awt.Color;
	import java.awt.Font;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.PrintWriter;
	import java.util.Scanner;
	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JTextField;
	import javax.swing.SwingConstants;


	public class AddCourse extends JFrame implements ActionListener{
	    
	    JLabel info;
	    JTextField f1,f2;
	    
	    public AddCourse(){
	        super("Add Course");
	        setSize(400,400);
	        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	        setLocationRelativeTo(null);        
	        setLayout(null);
	        
	        
	        JLabel lbl= new JLabel("Add Course to Student");
	        Font Title_Font = new Font("Cambria", Font.BOLD, 28);
	        lbl.setFont(Title_Font);
	        lbl.setBounds(50,20,300,50);
	        add(lbl);
	   
	        Font Label_Font = new Font("Cambria", Font.BOLD, 14);
	    
	        info= new JLabel("");
	        info.setForeground(Color.RED);
	        info.setFont(Label_Font);
	        info.setBounds(60,60,320,50);
	        add(info);

	        JLabel l1= new JLabel("Student ID*",SwingConstants.RIGHT);
	        l1.setFont(Label_Font);
	        l1.setBounds(30,100,120,50);
	        f1 = new JTextField(10);
	        f1.setBounds(160,110,150,30);

	        JLabel l2= new JLabel("Course Code*",SwingConstants.RIGHT);
	        l2.setFont(Label_Font);    
	        l2.setBounds(30,140,120,50);
	        f2 = new JTextField(10);
	        f2.setBounds(160,150,150,30);
	        
	        add(l1);
	        add(f1);
	        add(l2);
	        add(f2);
	        
	        JButton add_btn = new JButton("Add Course");
	        add_btn.setBounds(210,190,100,30);
	        add_btn.addActionListener(this);
	        add(add_btn);
	    }
	    
	    public void actionPerformed(ActionEvent e){    
	    
	        String std_name="";
	        String std_id = f1.getText().trim();
	        String code = f2.getText().trim();
	        boolean found1 = false , found2 = false;
	        
	        // read from student and course files to check if already added. 
	        Scanner std_Stream = null , course_Stream = null;

	        try{
	            std_Stream = new Scanner(new FileInputStream("student.txt"));
	            course_Stream = new Scanner(new FileInputStream("Course.txt"));
	            
	            //search for student is vaild or not
	            while(std_Stream.hasNextLine()){
	                String line = std_Stream.nextLine();
	                String[] tokens = line.split(","); 
	                if (tokens[3].equals(std_id)){
	                    found1 = true;
	                    std_name = tokens[0]+" "+tokens[1];
	                    break;
	                }// end if
	            } // end while loop 
	            
	            
	            //search for course is vaild or not
	            while(course_Stream.hasNextLine()){
	                String line = course_Stream.nextLine();
	                String[] tokens = line.split(","); 
	                if (tokens[0].equals(code)){
	                    found2 = true;
	                    break;
	                }// end if
	            } // end while        
	       
	        } // end try
	        catch (FileNotFoundException ex){
	            System.out.println("Files not found");
	            info.setText("Files are not exist.. check it");
	        }
	        
	        
	        
	        if (found2 &&  found1){
	            PrintWriter outStream = null;
	            try
	            {
	                outStream = new PrintWriter(new FileOutputStream("StudentCourse.txt",true));
	                outStream.println(std_id+","+std_name+","+code);
	                outStream.close();
	                info.setText("Course addedd successfully to a Student");
	            }
	            catch(FileNotFoundException ex)
	            {
	                System.out.println("Error opening the file studentCourse.txt "+ ex.getMessage());
	                info.setText("File studentCourse does not exist..");
	            }
	               
	        }// end if
	        else
	        {
	            info.setText("Check your student Id and Course Code");
	        } //end else


	        
	        
	    } // end action perform
	        
	}
	
	
	


