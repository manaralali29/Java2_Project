package java2project;


	import java.awt.Color;
	import java.awt.Font;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.PrintWriter;
	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JTextField;
	import javax.swing.SwingConstants;


public class AddStudents extends JFrame implements ActionListener{
	    
	    JLabel info;
	    JTextField TF1, TF2, TF3 , TF4 ,TF5,TF6;
	    
	    public AddStudents(){
	    
	        super("Add Students");
	        setSize(400,500);
	        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	        setLocationRelativeTo(null);
	        setLayout(null);
	    
	        
	        JLabel lbl= new JLabel("Add New Student");
	        Font Title_Font = new Font("Cambria", Font.BOLD, 28);
	        lbl.setFont(Title_Font);
	        lbl.setBounds(70,20,220,50);
	        add(lbl);
	   
	        Font Label_Font = new Font("Cambria", Font.BOLD, 14);
	    
	        info= new JLabel("");
	        info.setForeground(Color.RED);
	        info.setFont(Label_Font);
	        info.setBounds(50,80,320,50);
	        add(info);

	        //First name * , Last name*, Birthdate*, ID*,address, major, and Phone
	        JLabel l1= new JLabel("First Name*",SwingConstants.RIGHT);
	        l1.setFont(Label_Font);
	        l1.setBounds(70,120,80,50);
	        TF1 = new JTextField(10);
	        TF1.setBounds(160,130,150,30);

	        JLabel l2= new JLabel("Last Name*",SwingConstants.RIGHT);
	        l2.setFont(Label_Font);    
	        l2.setBounds(70,160,80,50);
	        TF2 = new JTextField(10);
	        TF2.setBounds(160,170,150,30);

	        JLabel l3= new JLabel("Birthdate*",SwingConstants.RIGHT);
	        l3.setFont(Label_Font);    
	        l3.setBounds(70,200,80,50);
	        TF3 = new JTextField(10);
	        TF3.setBounds(160,210,150,30);
	        
	        JLabel l4= new JLabel("ID*",SwingConstants.RIGHT);
	        l4.setFont(Label_Font);   
	        l4.setBounds(70,240,80,50);
	        TF4 = new JTextField(10);
	        TF4.setBounds(160,250,150,30);

	        JLabel l5= new JLabel("Address",SwingConstants.RIGHT);
	        l5.setFont(Label_Font);   
	        l5.setBounds(70,280,80,50);
	        TF5 = new JTextField(10);
	        TF5.setBounds(160,290,150,30);



	        JLabel l6= new JLabel("Phone",SwingConstants.RIGHT);
	        l6.setFont(Label_Font);   
	        l6.setBounds(70,320,80,50);
	        TF6 = new JTextField(10);
	        TF6.setBounds(160,330,150,30);        
	        
	        add(l1);
	        add(TF1);
	        add(l2);
	        add(TF2);
	        add(l3);
	        add(TF3);
	        add(l4);
	        add(TF4);
	        add(l5);
	        add(TF5);
	        add(l6);
	        add(TF6);        
	        
	        JButton add_btn = new JButton("Add");
	        add_btn.addActionListener(this);
	        add_btn.setBounds(230,370,80,30);

	        add(add_btn);
	        
	    }
	    
	    public void actionPerformed(ActionEvent e){
	        // read all data from gui
	        String fname = TF1.getText().trim();
	        String lname = TF2.getText().trim();
	        String birth = TF3.getText().trim();
	        String id = TF4.getText().trim();
	        String address = TF5.getText().trim();
	        String phone = TF6.getText().trim();
	        
	        
	        PrintWriter outStream = null;
	        try
	        {
	            outStream = new PrintWriter(new FileOutputStream("Student.txt",true));
	            outStream.println(fname+","+lname+","+birth+","+id+","+address+","+ phone);
	            outStream.close();
	            info.setText("Student added successfully..");
	        }
	        catch(FileNotFoundException ee)
	        {
	            System.out.println("Error opening the file student.txt "+ ee.getMessage());
	            info.setText("File Student does not exist..");
	        }
	        

	    }
	    
	}

