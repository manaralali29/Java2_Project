package java2project;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class ManageCourse extends JFrame implements ActionListener{
	

	public ManageCourse() {

	this.setTitle("Manage Course Window");
	this.setSize(400,350);
	this.setDefaultCloseOperation(HIDE_ON_CLOSE);
	this.setLayout(new BorderLayout());
			
	// menu
	JMenu Manage= new JMenu("MANAGE COURSES");
	
	this.add(Manage);
	
	//menu item		
	JMenuItem Add_Course = new JMenuItem("Add New Course");
	Add_Course.addActionListener(this);
	JMenuItem Display_Courses= new JMenuItem("Display Courses");
	Display_Courses.addActionListener(this);

	
	Manage.add(Add_Course);
	Manage.add(Display_Courses);

	
	
	//menu bar 
	JMenuBar menuBar= new JMenuBar();
	
	this.setJMenuBar(menuBar);
//	this.add(menuBar);
	menuBar.add(Manage);
	
	
	//icon	
	
	ImageIcon JUC_icon= new ImageIcon("juc.png");
	JLabel JUC_label=new JLabel(JUC_icon);
	//this.add(JUC_label);
	
	
	
	//massage 	
	JLabel JUC_text=new JLabel("welcome to JUC online services");
	//this.add(JUC_text);

	
	
	//font 
	JUC_text.setFont (new Font ("TimesRoman", Font.BOLD | Font.ITALIC, 17));
	
	

	//panel
	JPanel Panel1 = new JPanel(new FlowLayout());
	Panel1.add(menuBar);
	JPanel Panel2 = new JPanel(new FlowLayout());
	Panel2.add(JUC_text);
	Panel2.add(JUC_label);
	
	  //adding to the frame
	   this.add(Panel1,BorderLayout.NORTH);
	   this.add(Panel2,BorderLayout.CENTER);
	   
	 
}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		 String actioncommand= e.getActionCommand();
	        //System.out.println(actioncommand);
	        
	        if(actioncommand.equals("Add New Course")){
	            AddNewCourse Add_New_Course= new AddNewCourse();
	            Add_New_Course.setVisible(true);   
	        }
	        if(actioncommand.equals("Display Courses")){
	            DisplayCourses Display_Courses= new DisplayCourses();
	            Display_Courses.setVisible(true); 
		
	     }
	}
}