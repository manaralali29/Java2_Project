package java2project;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.*;


public class mainWindow extends JFrame implements ActionListener  {

	public mainWindow() {
		
		//window 2
		
				this.setTitle("Main Window");
				this.setSize(400,350);
				this.setDefaultCloseOperation(HIDE_ON_CLOSE);
				this.setLayout(new FlowLayout());
				
				
		// menu
				JMenu Manage= new JMenu("MANAGE");
				this.add(Manage);
				
		//menu item		
				JMenuItem Manage_Students_Window = new JMenuItem("Students");
				Manage_Students_Window.addActionListener(this);
				Manage.add(Manage_Students_Window);
				
				JMenuItem Manage_Courses_Window= new JMenuItem("Courses");
				Manage_Courses_Window.addActionListener(this);
				Manage.add(Manage_Courses_Window);
				
				
		//menu bar 
				JMenuBar menuBar= new JMenuBar();
				
				this.setJMenuBar(menuBar);
				this.add(menuBar);
				menuBar.add(Manage);
				
		//icon	
				
				ImageIcon JUC_icon= new ImageIcon("Unknown.png");
				JLabel JUC_label=new JLabel(JUC_icon);
				this.add(JUC_label);
				
				
		 
		//massage 	
				JLabel JUC_text=new JLabel("welcome to JUC online services");
				this.add(JUC_text);
			
				
				
			//font 
				JUC_text.setFont (new Font ("TimesRoman", Font.BOLD | Font.ITALIC, 17));
				
				this.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		 String actioncommand= e.getActionCommand();
	        System.out.println(actioncommand);
	        
	        if(actioncommand.equals("Students")){
	            ManageStudent Manage_Student= new ManageStudent();
	            Manage_Student.setVisible(true);   
	        }
	         if(actioncommand.equals("Courses")){
	            ManageCourse Manage_Course= new ManageCourse();
	            Manage_Course.setVisible(true);
		
	     }
	
	}
	
}
