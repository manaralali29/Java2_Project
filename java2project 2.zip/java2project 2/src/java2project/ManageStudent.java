package java2project;



import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class ManageStudent extends JFrame implements ActionListener{
	
	public ManageStudent(){
		
		
		
		this.setTitle("Manage Student Window");
		this.setSize(400,350);
		this.setDefaultCloseOperation(HIDE_ON_CLOSE);
		this.setLayout(new BorderLayout() );
				
		// menu
		JMenu Manage= new JMenu("MANAGE STUDENTS");
		this.add(Manage);
		
		//menu item		
		JMenuItem Add_Students = new JMenuItem("Add New Students");
		Add_Students.addActionListener(this);
		JMenuItem Display_Students= new JMenuItem("Display Students");
		Display_Students.addActionListener(this);
		JMenuItem Add_Course= new JMenuItem("Add Course");
		Add_Course.addActionListener(this);
		
		Manage.add(Add_Students);
		Manage.add(Display_Students);
		Manage.add(Add_Course);
		
		
		//menu bar 
		JMenuBar menuBar= new JMenuBar();
		
		this.setJMenuBar(menuBar);
	//	this.add(menuBar);
		menuBar.add(Manage);
		
		
		//icon	
		
		ImageIcon JUC_icon= new ImageIcon("juc.png");
		JLabel JUC_label=new JLabel(JUC_icon);
		//this.add(JUC_label);
		
		
		
		//massage 	
		JLabel JUC_text=new JLabel("welcome to JUC online services");
		//this.add(JUC_text);
	
		
		
		//font 
		JUC_text.setFont (new Font ("TimesRoman", Font.BOLD | Font.ITALIC, 17));
		
		

		//panel
		JPanel Panel1 = new JPanel(new FlowLayout());
		Panel1.add(menuBar);
		JPanel Panel2 = new JPanel(new FlowLayout());
		Panel2.add(JUC_text);
		Panel2.add(JUC_label);
		
		  //adding to the frame
		   this.add(Panel1,BorderLayout.NORTH);
		   this.add(Panel2,BorderLayout.CENTER);
   

		
	
	
	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		
		        String actioncommand= e.getActionCommand();
		        
		        
		        if(actioncommand.equals("Add New Students")){
		        	System.out.println("Manage");
		            AddStudents Add_Students= new AddStudents();
		            Add_Students.setVisible(true);   
		        }
		        if(actioncommand.equals("Display Students")){
		            DisplayStudents Display_Students= new DisplayStudents();
		            Display_Students.setVisible(true);   
		        }   
		            
		        if(actioncommand.equals("Add Course")){
		            AddCourse Add_Course= new AddCourse();
		            Add_Course.setVisible(true);   
		        }  
		    }
		
	}
	

	

	


